<?php
/*-----------------------------------------------------------
Class: Parser - Parses input file of specific format

Origin Date: June 17, 2010
Modified Date: July 16, 2010

Methods
construct
------------------------------------------------------------*/

class Parser {
   public $file;
   public $section1;
   public $section2;
   public $entries;

   public $title;
   public $status;
   public $last_activity;
   public $open_bal;
   public $close_bal;
   public $open_date;
   public $payments;
   public $x30;
   public $x60;
   public $x90;
   public $type;
   public $past_due;
   public $mon_pay;
   public $twentyfour_month;
   public $status_str;
   public $type_str;

   public $csv;

   private $isDataVerified;

   public function __construct($filename, $data, $outputfile = 'parsed_credit_bureaus.csv') {
      // open file
      $fh = fopen($filename, 'r');

      while (!feof($fh)) {
         $this->file[] = fgets($fh);
      }

      // first_name,last_name,creditScore,ssnIssued,dateSince,zipCode,ssnVer,maxR1Balance,ONES,TWOS,THREES,FOURS,FIVES,SIXESSEVENS,EIGHTS,NINES,openTotals,dates_in_last_180_days,title,status,last_activity,open_bal,close_bal,open_date,payments,x30,x60,x90,type,past_due,mon_pay,twentyfour_month,status_str,type_str


      $this->cropFile();
      $this->isolateEntries();
      $this->assignVariables();
      $this->generateCsv($data);    // use customer data from parseCreditBureaus.php
      $this->writeFile('parsed_credit_bureaus.csv');
   }

   /**
    * removes all information outside of the hyphenated delimiters
    */
   private function cropFile() {
      for ($i = 0; $i < sizeof($this->file); $i++) {
         // the hyphen page delimiters
         if (preg_match('/^[-]{80}/', $this->file[$i])) {
            $delimit[] = $i;
         }
      }

      if (count($delimit) == 5) {      // There exists revolving debt
         $offset = $delimit[2] + 1;
         $length = $delimit[3] - $delimit[2] - 3;  // the last three lines detail the installment totals
      } else {
         $offset = $delimit[1] + 1;    // No revolving debt section
         $length = $delimit[2] - $delimit[1] - 3;
      }
      $this->file = array_slice($this->file, $offset, $length);

      // print_r($this->file);
   }

   /**
    * partition separate entries
    */
   private function isolateEntries() {
      $j = 0;
      for ($i = 0; $i < sizeof($this->file); $i++) {
         if (preg_match('/^\s*$/', $this->file[$i])) {
            $j++;
         } else {
            $this->entries[$j][] = $this->file[$i];
         }
      }
   }

   /**
    * assign variables
    */
   private function assignVariables() {
      if (is_array($this->entries) && sizeof($this->entries > 0)) {
         foreach ($this->entries as $entry) {

            // get values from first line; check for asterisks
            if (strpos($entry[0], '*')) {
               $index0_tmp = preg_split('/\s+/', substr($entry[0], strpos($entry[0], '*')));
            } else {
               $index0_tmp = preg_split('/\s+/', substr($entry[0], 11));
            }

            // get values for second line
            $index1_tmp = preg_split('/\s+/', trim($entry[1]));

            // x30, x60, x90
            $x = explode('-', trim($index0_tmp[8], '()'));

            // set title; check for asterisk
            if (strpos($entry[0], '*')) { // if the asterisks is where it's supposed to be...
               $this->title[] = trim(substr($entry[0], 0, strpos($entry[0], '*')));
            } else {                      // otherwise take the first characters up to the first number
               $this->title[] = trim(substr($entry[0], 0, 11));
            }

            $this->status[]         = $index0_tmp[1];
            $this->last_activity[]  = $index0_tmp[6];
            $this->open_bal[]       = $index0_tmp[4];
            $this->close_bal[]      = $index0_tmp[5];
            $this->payments[]       = $index0_tmp[7];
            $this->x30[]            = $x[0];
            $this->x60[]            = $x[1];
            $this->x90[]            = $x[2];
            $this->type[]           = $index1_tmp[0];       // index1
            $this->open_date[]      = $index1_tmp[1];       // index1
            $this->status_str[]     = $entry[2];
            $this->type_str[]       = isset($entry[3]) ? $entry[3] : '';

            // for index1_tmp, this line can be in 3 different format
            // the first two items will always be [type] and [opendate] - these are set above
            if (sizeof($index1_tmp) == 3) {
               // type; opendate; mon_pay (term)
               $this->mon_pay[] = $index1_tmp[2];
            } else if (sizeof($index1_tmp) == 4) {
               if (strlen($index1_tmp[3]) > 4) {
                  // type; opendate; mon_pay; 24 month
                  $this->mon_pay[] = $index1_tmp[2];
                  $this->twentyfour_month[] = $index1_tmp[3];
               } else {
                  // type; opendate; past_due; mon_pay
                  $this->past_due[] = $index1_tmp[2];
                  $this->mon_pay[] = $index1_tmp[3];
               }
            }
         }
         $this->isDataVerified = true;
      } else {
         $this->isDataVerified = false;
      }
   }

   /**
    * generate csv file with filename plus csv extension
    */
   private function generateCsv($data) {
      if ($this->isDataVerified) {
         for ($i = 0; $i < sizeof($this->title); $i++) {
            $this->csv .= trim($data['first_name'])               . ',';
            $this->csv .= trim($data['last_name'])                . ',';
            $this->csv .= trim($data['creditScore'])              . ',';
            $this->csv .= trim($data['ssnIssued'])                . ',';
            $this->csv .= trim($data['dateSince'])                . ',';
            $this->csv .= trim($data['zipCode'])                  . ',';
            $this->csv .= trim($data['ssnVer'])                   . ',';
            $this->csv .= trim($data['maxR1Balance'])             . ',';
            $this->csv .= trim($data['ONES'])                     . ',';
            $this->csv .= trim($data['TWOS'])                     . ',';
            $this->csv .= trim($data['THREES'])                   . ',';
            $this->csv .= trim($data['FOURS'])                    . ',';
            $this->csv .= trim($data['FIVES'])                    . ',';
            $this->csv .= trim($data['SIXES'])                    . ',';
            $this->csv .= trim($data['SEVENS'])                   . ',';
            $this->csv .= trim($data['EIGHTS'])                   . ',';
            $this->csv .= trim($data['NINES'])                    . ',';
            $this->csv .= trim($data['openTotals'])               . ',';
            $this->csv .= trim($data['dates_in_last_180_days'])   . ',';
            $this->csv .= trim($this->title[$i])                  . ',';
            $this->csv .= trim($this->status[$i])                 . ',';
            $this->csv .= trim($this->last_activity[$i])          . ',';
            $this->csv .= trim($this->open_bal[$i])               . ',';
            $this->csv .= trim($this->close_bal[$i])              . ',';
            $this->csv .= trim($this->open_date[$i])              . ',';
            $this->csv .= trim($this->payments[$i])               . ',';
            $this->csv .= trim($this->x30[$i])                    . ',';
            $this->csv .= trim($this->x60[$i])                    . ',';
            $this->csv .= trim($this->x90[$i])                    . ',';
            $this->csv .= trim($this->type[$i])                   . ',';
            $this->csv .= trim($this->past_due[$i])               . ',';
            $this->csv .= trim($this->mon_pay[$i])                . ',';
            $this->csv .= trim($this->twentyfour_month[$i])       . ',';
            $this->csv .= trim($this->status_str[$i])             . ',';
            $this->csv .= trim($this->type_str[$i])               . ',';
            $this->csv .= "\n";
         }
      }

      // echo $this->csv;
   }

   /**
    * write filename plus csv extension
    */
   private function writeFile($filename) {
      if ($this->isDataVerified) {
         $fh = fopen($filename, 'a');
         fwrite($fh, $this->csv);
         fclose($fh);
      }
   }
}
