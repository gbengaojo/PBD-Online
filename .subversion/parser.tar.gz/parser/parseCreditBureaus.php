<?php

require 'Parser.php';

// use names?
$use_names = false;

// input .csv file
$names_file = "names.csv";

// output .csv file
$output = "parsed_credit_bureaus.csv";

// directory that holds html files to parse
$directory = "credit_bureaus";

// the number of installments to record
$max_installments = 50;

/* ----------------------------------------------------------------------------

DO NOT EDIT BELOW HERE!

---------------------------------------------------------------------------- */

require_once("simplehtmldom/simple_html_dom.php");
$page = new simple_html_dom();

set_time_limit(0);

// open .csv file ('a' options means append)
$fh = fopen($output, 'a') or die("Can't open .csv file!");

// get names
$names = getNames($names_file);

// loop through all files in folder
if($handle = opendir($directory)) {
    while (false !== ($file = readdir($handle))) {
        if ($file != "." && $file != "..") {
			
			// load html file
			$html = file_get_contents($directory."/".$file);
			
			$report = getCreditReport($html);
			
			// Get first and last names
			$name = preg_match('/\n\*(\w[\w ]*),([\w]*)/', $report, $matches);
			$first_name = $matches[2];
			$last_name = $matches[1];

			// Only proceed if the file we're looking at is for a user who is in the supplied list of names
			if($use_names) {
				$parse_data = in_array(ucwords(strtolower("$last_name, $first_name")), $names);
			} else {
				$parse_data = true;
			}
			
			if($parse_data) {
				
				// get the credit score
				preg_match('/OPTION: (\d+)/', $report, $matches);
				$creditScore = $matches[1];
				
				// grab the SSN issued date
				preg_match('/SSN ISSUED-(\d+)/', $report, $matches);
				$ssnIssued = $matches[1];
				
				// grab the year since
				preg_match('/SINCE \d{2}\/\d{2}\/(\d{2})\s/', $report, $matches);
				$dateSince = $matches[1];
				
				// grab the zip
				preg_match('/[A-Z]{2},(\d{5}),/', $report, $matches);
				$zipCode = $matches[1];
				
				// get the SSN ver
				preg_match('/SSN VER: ([NY]{1})/', $report, $matches);
				$ssnVer = $matches[1];
				if($ssnVer == "") {
					$ssnVer = "N";
				}

				// find the highest R1 balance if it exists
				$maxR1Balance = "";
				if(strpos($report, "REVOLVING TOTALS") !== false) {
					preg_match_all('/R1\s+\d{2}\/\d{2}\s+\S+\s+\S+\s+(\d+)/', $report, $matches);
					if(count($matches[1]) > 0) {
						$maxR1Balance = max($matches[1]);
					}
				}

				// get delinquencies if they exist
				if(strpos($report, "HIST DEL") !== false) {
					preg_match('/HIST DEL-\s*(\d-ONES?)?,?\s*(\d-TWO?)?,?\s*(\d-THREES?)?,?\s*(\d-FOURS?)?,?\s*(\d-FIVES?)?,?\s*(\d-SIXE?S?)?,?\s*(\d-SEVENS?)?,?\s*(\d-EIGHTS?)?,?\s*(\d-NINES?)?/s', $report, $matches);
					
					$ONES = substr($matches[1], 0, strpos($matches[1], "-"));
					$TWOS = substr($matches[2], 0, strpos($matches[2], "-"));
					$THREES = substr($matches[3], 0, strpos($matches[3], "-"));
					$FOURS = substr($matches[4], 0, strpos($matches[4], "-"));
					$FIVES = substr($matches[5], 0, strpos($matches[5], "-"));
					$SIXES = substr($matches[6], 0, strpos($matches[6], "-"));
					$SEVENS = substr($matches[7], 0, strpos($matches[7], "-"));
					$EIGHTS = substr($matches[8], 0, strpos($matches[8], "-"));
					$NINES = substr($matches[9], 0, strpos($matches[9], "-"));
				} else {
					$ONES = 0;
					$TWOS = 0;
					$THREES = 0;
					$FOURS = 0;
					$FIVES = 0;
					$SIXES = 0;
					$SEVENS = 0;
					$EIGHTS = 0;
					$NINES = 0;
				}
				
				// find the open total if it exists
				if(strpos($report, "OPEN TOTALS") !== false) {
					preg_match('/OPEN TOTALS.*\n\s*(\d+)/', $report, $matches);
					$openTotals = $matches[1];
				}
				
				// get inquiries
				if(strpos($report, "*INQS") !== false) {
					// Get all inquiries in separate string
					preg_match('/\*INQS(.*)END/s', $report, $inquiry_block);
					$inquiries = $inquiry_block[1];
					
					preg_match_all('/(\d{2}\/(\d{2}\/)?\d{2,4})/', $inquiries, $dates);
					
					$todays_date = strtotime(date("m/d/y"));
					$dates_in_last_180_days = 0;
					
					foreach($dates[0] as $date) {
						
						// if the date is MM/YYYY, then make it MM/01/YYYY
						if(substr_count($date, "/") == 1) {
							$date = preg_replace("/(\d{2})\/(\d{2,4})/", "$1/01/$2", $date);
						}
						
						$seconds = strtotime($date);
						
						if($seconds+15552000 >= $todays_date) {
							$dates_in_last_180_days++;
						}
					}
				}
				
				// get installments if they exit
				if(strpos($report, "INSTALLMENT TOTALS") !== false) {
					
					preg_match("/OPEN TOTALS.*-{83}(.*)INSTALLMENT TOTALS.*-{83}.*GRAND TOTALS/s", $report, $block);
					
					$installments = parseInstallments($block[1]);
				}
				
				// construct csv line
				$line = "$first_name, $last_name, $creditScore, $ssnIssued, $dateSince, $zipCode, $ssnVer, $maxR1Balance, $ONES, $TWOS, $THREES, $FOURS, $FIVES, $SIXES, $SEVENS, $EIGHTS, $NINES, $openTotals, $dates_in_last_180_days, $installments\n";

            // send data to Parser class to handle installments
            $data = array('first_name'             => $first_name,
                          'last_name'              => $last_name,
                          'creditScore'            => $creditScore,
                          'ssnIssued'              => $ssnIssued, 
                          'dateSince'              => $dateSince,
                          'zipCode'                => $zipCode,
                          'ssnVer'                 => $ssnVer,
                          'maxR1Balance'           => $maxR1Balance,
                          'ONES'                   => $ONES,
                          'TWOS'                   => $TWOS,
                          'THREES'                 => $THREES,
                          'FOURS'                  => $FOURS,
                          'FIVES'                  => $FIVES,
                          'SIXES'                  => $SIXES,
                          'SEVENS'                 => $SEVENS,
                          'EIGHTS'                 => $EIGHTS,
                          'NINES'                  => $NINES,
                          'openTotals'             => $openTotals,
                          'dates_in_last_180_days' => $dates_in_last_180_days);


            $parser = new Parser($directory . '/' . $file, $data);
            //echo '<pre>' . $installments . "\n<br>";
				
				// write to .csv file (let the Parser class write to the csv file
				// fwrite($fh, $line);
			} else {
			   echo "$last_name, $first_name was not in the supplied list of names. Skipping.<br/>\n";
			}
        }
    }
    
    // clean up
	fclose($fh);
    closedir($handle);
    
    // display link to .csv file
    echo "Done. Please click <a href='$output'>here</a> to download the CSV file.";
    
}



function convertToMonths($years, $months) {
	// return a blank string if arguments are blank
	if($years == "" && $months == "") {
		return "";
	}
	
	return ($years*12)+$months;
}

function getNames($filename) {
	$file = file_get_contents($filename);
	
	preg_match_all('/\d{1,2}\/\d{1,2}\/\d{4},"([^"]*)"/', $file, $matches);
	
	// Use array_unique() here to remove duplicates
	return array_unique($matches[1]);
}

function getCreditReport($html) {
	// Get DOM object
	global $page;
	
	// Load HTML from a string
	$page->load($html);
	
	// Find the <div> tag with id = bureaucontent
	$div = $page->find('div[id=bureaucontent]');
	$div = $div[0];
		
	// Get the text inside the <pre> tag
	preg_match_all('/<pre>(.*)<\/pre>/is', $div, $matches);

   // echo '<pre>' . $matches[1][0];
	return trim($matches[1][0]); // trim to remove whitespace that may exist before and after text
}

function parseInstallments($text) {
	
	global $max_installments;
	
	$number_of_parsed_installments = 0;
	
	# split the block of text by transaction
	$items = preg_split("/\n\s\s\n/", $text);
	
	# For each transaction, use this regex to extract all the necessary attributes
	foreach ($items as $item) {
		preg_match("/(.*?)\s*\*\S+\s(\S+)\s\S+\s+\-+\s+(\d+)\s+(\d+)\s+(\S+)\s+(\d+)?\s?\(?(\d?\d?)\-?(\d?\d?)\-?(\d?\d?)\)?.*\n(\w\/)\s+(\d+\/\d+)\s?\s?\s?\s?\s?(\d?\d?\d?\d?)\s+(\d?\d?\d?\d?).*\n?/", $item, $matches);
		array_shift($matches);
	
		# match the subsequent lines in the transaction, append the attributes
		if (preg_match("/.*\n.*\n(.*)\n?/",$item, $match_line1))
			$matches[]=trim($match_line1[1]);
		else
			$matches[]="";
		if (preg_match("/.*\n.*\n.*\n(.*)\n?/",$item, $match_line2)) 
			$matches[]=trim($match_line2[1]);
		else
			$matches[]="";
		
		if($number_of_parsed_installments < $max_installments) {
			# write to return string
			$csv = implode(", ", $matches);
			
			// Title, Status, Open Bal, Close Bal, Last Activity, No of Payments, x30, x60, x90, Type, Open Date, Past Due, Mon Pay, Description1, Description2
			$return_string .= $csv;
			$number_of_parsed_installments++;
		}
	}
	
    	// fill in commas for the number of installments that were not found
	for($i=0; $i<($max_installments-$number_of_parsed_installments); $i++) {
		$return_string .= ",,,,,,,,,,,,,,,";
	}
	
	return $return_string;
}

?>
